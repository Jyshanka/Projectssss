package com.bosch.employeeemgmt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bosch.employeeemgmt.bean.Employee;
import com.bosch.employeeemgmt.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@GetMapping(path="/employees")
	public List<Employee> getEmployees(){
		return service.getEmployees();
	}
	
	@PostMapping(path="")

}
