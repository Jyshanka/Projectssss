package com.bosch.employeeemgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeemgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeemgmtApplication.class, args);
	}

}
